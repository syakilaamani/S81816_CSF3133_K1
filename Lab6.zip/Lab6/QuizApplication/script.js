// Questions Array
const questions = [
    {
        question: "What does HTML stand for?",
        options: [
            "Hyper Text Markup Language",
            "High Text Machine Language",
            "Hyperlinks Text Mark Language",
            "Home Tool Markup Language"
        ],
        answer: "Hyper Text Markup Language"
    },

    {
        question: "Which language is used to style a webpage?",
        options: [
            "HTML",
            "CSS",
            "Java",
            "Python"
        ],
        answer: "CSS"
    },

    {
        question: "Which tag is used to link JavaScript?",
        options: [
            "css",
            "javascript",
            "script",
            "js"
        ],
        answer: "script"
    },

    {
        question: "Which method displays an alert box?",
        options: [
            "alert()",
            "display()",
            "message()",
            "show()"
        ],
        answer: "alert()"
    },

    {
        question: "Which keyword declares a variable in JavaScript?",
        options: [
            "int",
            "var",
            "string",
            "define"
        ],
        answer: "var"
    }
];

// Variables
let currentQuestion = 0;
let score = 0;
let timer;
let timeLeft = 15;
let selectedQuestions = [];
let answered = false;


// Shuffle Questions
function shuffleQuestions() {

    selectedQuestions = [...questions];

    for (let i = selectedQuestions.length - 1; i > 0; i--) {

        let j = Math.floor(Math.random() * (i + 1));

        [selectedQuestions[i], selectedQuestions[j]] =
        [selectedQuestions[j], selectedQuestions[i]];
    }
}


// Start Quiz
function startQuiz() {

    currentQuestion = 0;
    score = 0;

    shuffleQuestions();

    document.getElementById("start-screen").classList.add("hidden");

    document.getElementById("result-screen").classList.add("hidden");

    document.getElementById("quiz-screen").classList.remove("hidden");

    displayQuestion();
}


// Start Timer
function startTimer() {

    clearInterval(timer);

    timeLeft = 15;

    document.getElementById("timer").textContent = timeLeft;

    timer = setInterval(function() {

        timeLeft--;

        document.getElementById("timer").textContent = timeLeft;

        if (timeLeft <= 0) {

            clearInterval(timer);

            checkAnswer(true);
        }

    }, 1000);
}


// Display Question
function displayQuestion() {

    answered = false;

    const question = selectedQuestions[currentQuestion];

    document.getElementById("question-number").textContent =
        "Question " + (currentQuestion + 1) +
        " / " + selectedQuestions.length;

    document.getElementById("question").textContent =
        question.question;

    const optionsContainer = document.getElementById("options");

    optionsContainer.innerHTML = "";

    question.options.forEach(function(option) {

        optionsContainer.innerHTML += `
            <label class="option">
                <input type="radio" name="answer" value="${option}">
                ${option}
            </label>
        `;

    });

    document.getElementById("feedback").textContent = "";

    document.getElementById("submit-btn").classList.remove("hidden");

    document.getElementById("submit-btn").disabled = false;

    document.getElementById("next-btn").classList.add("hidden");

    startTimer();
}


// Check Answer
function checkAnswer(timeOut = false) {

    if (answered) return;

    answered = true;

    clearInterval(timer);

    const selected = document.querySelector(
        'input[name="answer"]:checked'
    );

    const correctAnswer = selectedQuestions[currentQuestion].answer;

    if (timeOut) {

        document.getElementById("feedback").textContent =
            "Time is up! The correct answer is: " + correctAnswer;

    } else if (selected === null) {

        document.getElementById("feedback").textContent =
            "Please select an answer! The correct answer is: " + correctAnswer;

    } else if (selected.value === correctAnswer) {

        score++;

        document.getElementById("feedback").textContent =
            "Correct! Well done.";

    } else {

        document.getElementById("feedback").textContent =
            "Incorrect! The correct answer is: " + correctAnswer;
    }

    // Disable answer options
    document.querySelectorAll('input[name="answer"]').forEach(function(input) {

        input.disabled = true;

    });

    document.getElementById("submit-btn").classList.add("hidden");

    document.getElementById("next-btn").classList.remove("hidden");
}


// Next Question
function nextQuestion() {

    currentQuestion++;

    if (currentQuestion < selectedQuestions.length) {

        displayQuestion();

    } else {

        showResult();
    }
}


// Display Final Score
function showResult() {

    clearInterval(timer);

    document.getElementById("quiz-screen").classList.add("hidden");

    document.getElementById("result-screen").classList.remove("hidden");

    document.getElementById("score").textContent =
        "Your Score: " + score + " / " + selectedQuestions.length;
}
